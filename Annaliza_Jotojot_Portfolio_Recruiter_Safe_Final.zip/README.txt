ANNALIZA B. JOTOJOT — EXECUTIVE PORTFOLIO
==========================================

HOSTING-READY PACKAGE
----------------------
This folder contains everything required to publish the portfolio as a static website.

Files:
- index.html — responsive portfolio website
- annaliza-headshot.jpg — optimized professional headshot
- Annaliza_Jotojot_CV.pdf — downloadable CV

IMPORTANT
---------
Keep all three files in the same folder. Do not rename them unless you also update
index.html references.

RECOMMENDED HOSTING: GITHUB PAGES
----------------------------------
1. Create/sign in to a GitHub account.
2. Create a new public repository, e.g. annaliza-jotojot-portfolio.
3. Upload index.html, annaliza-headshot.jpg, and Annaliza_Jotojot_CV.pdf to the
   repository root.
4. Open the repository's Settings > Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select the main branch and the /(root) folder, then save.
7. Wait for GitHub Pages to publish the site. GitHub will provide the public URL.

BEFORE SENDING TO EMPLOYERS
---------------------------
Open the published URL in:
- Chrome/Edge on desktop
- Chrome/Safari on a phone

Test:
- all navigation links
- Download CV buttons
- LinkedIn button
- Email Me button
- mobile Menu button
- headshot loading

PRIVACY NOTE
------------
The public portfolio is configured to display only one primary mobile number and
uses a broader location label (Bulacan, Philippines). The downloadable CV retains
its full contact details as provided. Review public contact information before
publishing if you prefer additional privacy.
